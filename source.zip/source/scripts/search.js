const button = document.querySelector('button');

if (button) {
    button.textContent = '> ' + button.textContent;
}